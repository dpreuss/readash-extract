WITH query AS
  ( SELECT last_time_generic_current.volume_name AS volume,
           atime_age AS atime,
           ROUND(SIZE / (1024 * 1024 * 1024.0), 2) AS "size logical (GiB)",
           ROUND(physical_size / (1024 * 1024 * 1024.0), 2) AS "size physical (GiB)",
           CASE
               WHEN COST = 0 THEN 0.025 * physical_size / (1024 * 1024 * 1024.0)
               ELSE COST
           END,
           physical_size
   FROM sf_reports.last_time_generic_current
   WHERE atime_age IN ('Previous Years: 1-2',
                       'Previous Years: 2-3',
                       'Previous Years: > 3') )
SELECT '$'||to_char(sum(cost), '999G999G999') as "Cost",
        ROUND(Sum(physical_size) / (1024*1024*1024.0), 2) as "Size"
FROM query