/***********************************************************************************************************
 *
 * Starfish Storage Corporation ("Starfish") CONFIDENTIAL
 * Unpublished Copyright (c) 2011-2021 Starfish Storage Corporation, All Rights Reserved.
 *
 * NOTICE: This file and its contents (1) constitute Starfish's "External Code" under Starfish's most-recent
 * Limited Software End-User License Agreement, and (2) is and remains the property of Starfish. The
 * intellectual and technical concepts contained herein are proprietary to Starfish and may be covered by
 * U.S. and/or foreign patents or patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Starfish. Access to the source code contained herein is hereby
 * forbidden to anyone except (A) current Starfish employees, managers, or contractors who have executed
 * confidentiality or nondisclosure agreements explicitly covering such access, and (B) licensees of
 * Starfish's software.
 *
 * ANY REPRODUCTION, COPYING, MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, OR PUBLIC DISPLAY OF OR
 * THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF STARFISH IS STRICTLY PROHIBITED
 * AND IS IN VIOLATION OF APPLICABLE LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS
 * FILE OR ITS CONTENTS AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE, OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY DESCRIBE, IN
 * WHOLE OR IN PART.
 *
 * FOR U.S. GOVERNMENT CUSTOMERS REGARDING THIS DOCUMENTATION/SOFTWARE
 *   These notices shall be marked on any reproduction of this data, in whole or in part.
 *   NOTICE: Notwithstanding any other lease or license that may pertain to, or accompany the delivery of,
 *   this computer software, the rights of the Government regarding its use, reproduction and disclosure are
 *   as set forth in Section 52.227-19 of the FARS Computer Software-Restricted Rights clause.
 *   RESTRICTED RIGHTS NOTICE: Use, duplication, or disclosure by the Government is subject to the
 *   restrictions as set forth in subparagraph (c)(1)(ii) of the Rights in Technical Data and Computer
 *   Software clause at DFARS 52.227-7013.
 *
 ***********************************************************************************************************/
WITH churn_raw AS (
    SELECT
        COALESCE(volume.display_name, volume.name) AS volume_name,
        -- line below is: convert scan.heartbeat to epoch (seconds since 1970), round to X days, convert back to date
        to_timestamp(ROUND(EXTRACT(EPOCH FROM scan.heartbeat) / (3600 * 24 * {{group_by_days}})) * (3600 * 24 * {{group_by_days}}) )::date AS date,
        COALESCE(SUM((stats#>>'{processing_stats,ADDED_DIR_COUNT}')::BIGINT), 0) AS added_dir_count,
        COALESCE(SUM((stats#>>'{processing_stats,ADDED_FILE_COUNT}')::BIGINT), 0) AS added_file_count,
        COALESCE(SUM((stats#>>'{processing_stats,REMOVED_DIR_COUNT}')::BIGINT), 0) AS removed_dir_count,
        COALESCE(SUM((stats#>>'{processing_stats,REMOVED_FILE_COUNT}')::BIGINT), 0) AS removed_file_count,
        COALESCE(SUM((stats#>>'{processing_stats,CHANGED_DIR_COUNT}')::BIGINT), 0) AS changed_dir_count,
        COALESCE(SUM((stats#>>'{processing_stats,CHANGED_FILE_COUNT}')::BIGINT), 0) AS changed_file_count,
        COALESCE(SUM((stats#>>'{processing_stats,ADDED_DIR_SIZE}')::BIGINT), 0) AS added_dir_size,
        COALESCE(SUM((stats#>>'{processing_stats,ADDED_FILE_SIZE}')::BIGINT), 0) AS added_file_size,
        COALESCE(SUM((stats#>>'{processing_stats,REMOVED_DIR_SIZE}')::BIGINT), 0) AS removed_dir_size,
        COALESCE(SUM((stats#>>'{processing_stats,REMOVED_FILE_SIZE}')::BIGINT), 0) AS removed_file_size,
        COALESCE(SUM((stats#>>'{processing_stats,CHANGED_DIR_SIZE}')::BIGINT), 0) AS changed_dir_size_delta,
        COALESCE(SUM((stats#>>'{processing_stats,CHANGED_FILE_SIZE}')::BIGINT), 0) AS changed_file_size_delta
    FROM sf_scans.scan
    LEFT JOIN sf_scans.loader_info ON loader_info.scan_id = scan.id
    LEFT JOIN sf_volumes.volume ON scan.volume_id = volume.id
    WHERE scan.state_name = 'done' AND
        scan.heartbeat >= now() - interval '{{number_of_days_to_look_back}} days'
    GROUP BY volume_name, date
    ORDER BY volume_name, date DESC
)
SELECT
--    volume_name AS "VOLUME NAME::filter", -- ::filter is magic word for redash
   date,
    SUM(added_dir_count) + SUM(added_file_count) AS "added files",
    SUM(removed_dir_count) + SUM(removed_file_count) AS "removed files",
    SUM(- removed_dir_count - removed_file_count) AS "removed files negative",
    SUM(changed_dir_count + changed_file_count) AS "changed files",
    ROUND(SUM((added_dir_size + added_file_size)::NUMERIC / (1024 * 1024 * 1024.0)), 2) AS "added files size (GiB)",
    ROUND(SUM((removed_dir_size + removed_file_size) / (1024 * 1024 * 1024.0)), 2) AS "removed files size (GiB)",
    ROUND(SUM( ( - removed_dir_size - removed_file_size) / (1024 * 1024 * 1024.0))::NUMERIC, 2) AS "removed files size negative (GiB)",
    ROUND((SUM(changed_dir_size_delta + changed_file_size_delta) / (1024 * 1024 * 1024.0))::NUMERIC, 2) AS "changed files size delta (GiB)"
FROM churn_raw GROUP BY date ORDER BY date;
