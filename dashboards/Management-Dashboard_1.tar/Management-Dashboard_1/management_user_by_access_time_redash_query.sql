WITH query AS (
    SELECT
        user_name as user,
        group_name as group,
        uid,
        gid,
        atime_age as atime,
        mtime_age as mtime,
        sum(ROUND(size / (1024 * 1024 * 1024.0), 2)) AS "size logical",
        sum(ROUND(physical_size / (1024 * 1024 * 1024.0), 1)) AS "Physical",
        sum(count) as "Count",
        ROUND(sum(cost)::NUMERIC, 0) as "Cost"
    FROM sf_reports.last_time_generic_current
    WHERE (ROUND(size / (1024 * 1024 * 1024.0), 2) > 0)
    GROUP by user_name,group_name,uid,gid,atime_age,mtime_age
    ORDER by sum(size) desc
    limit 20
), is_empty AS (
    SELECT
        CASE
            WHEN EXISTS (SELECT * FROM query LIMIT 1) THEN 0
            ELSE 1
        END AS val
) SELECT * FROM query
UNION ALL
SELECT
    NULL AS user,
    NULL AS group,
    NULL AS uid,
    NULL AS gid,
    NULL AS atime,
    NULL AS mtime,
    NULL AS "size logical (GiB)",
    NULL AS "size physical (GiB)",
    NULL AS count,
    NULL AS cost
FROM is_empty WHERE is_empty.val = 1;
