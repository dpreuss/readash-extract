WITH fs_entries_with_flat_tags AS (
    SELECT fs_entry_id, array_agg(name_id) AS tag_ids
    FROM sf.tag_value_current
    WHERE namespace_id = (SELECT id FROM sf.tag_namespace WHERE name = '')  -- default tag namespace
    GROUP BY fs_entry_id
),
tag_with_path  AS (
    SELECT dir.volume_id, dir.path, tag.name_id
    FROM sf.dir_current AS dir
        JOIN sf.tag_value_current AS tag
            ON dir.id = tag.fs_entry_id
                AND namespace_id = (SELECT id FROM sf.tag_namespace WHERE name = '')  -- default tag namespace
),
dirs_with_flat_tags AS (
    SELECT dir.id, array_agg(tag.name_id) AS tag_ids
    FROM sf.dir_current AS dir
        INNER JOIN tag_with_path AS tag
            -- regexp_replace is inlined from sf_internal.subtree_pattern
            ON tag.volume_id = dir.volume_id AND
            (dir.path LIKE regexp_replace(tag.path, '(%|_)', '\\\1', 'g') || '/%' OR dir.path = tag.path OR tag.path = '')
    GROUP BY dir.id
),
files_with_tag AS (
    -- DISTINCT is required to remove duplicates from merging arrays (file got the same tag inherited and directly assigned)
    SELECT DISTINCT file.id,
                    file.volume_id,
                    file.size,
                    u.name,
                    current_timestamp::date - atime::date AS atime_days,
                    current_timestamp::date - mtime::date AS mtime_days,
                    unnest((dwt.tag_ids || tag.tag_ids)::BIGINT[]) AS tag_id
    FROM sf.file_current AS file
        LEFT JOIN dirs_with_flat_tags AS dwt ON file.parent_id = dwt.id
        LEFT JOIN fs_entries_with_flat_tags AS tag ON file.id = tag.fs_entry_id
        LEFT JOIN sf.uid_mapping u ON file.uid = u.uid AND file.volume_id = u.volume_id
),
tag_per_vol_agg AS (
    SELECT tag_id,
           volume_id,
           name,
           SUM(size) AS size,
           COUNT(*) AS count,
           CASE
                  WHEN                       atime_days >= 1095 THEN 'Previous Years: > 3'
                  WHEN 1095 > atime_days AND atime_days >= 730  THEN 'Previous Years: 2-3'
                  WHEN 730  > atime_days AND atime_days >= 365  THEN 'Previous Years: 1-2'
                  WHEN 365  > atime_days AND atime_days >= 180  THEN 'Previous Months: 6-12'
                  WHEN 180  > atime_days AND atime_days >= 90   THEN 'Previous Months: 3-6'
                  WHEN 90   > atime_days AND atime_days >= 30   THEN 'Previous Months: 1-3'
                  WHEN 30   > atime_days AND atime_days >= 0    THEN 'Previous Months: 0-1'
                  ELSE 'future'
           END AS atime_age,
           CASE
               WHEN                       mtime_days >= 1095 THEN 'Previous Years: > 3'
               WHEN 1095 > mtime_days AND mtime_days >= 730  THEN 'Previous Years: 2-3'
               WHEN 730 > mtime_days AND  mtime_days >= 365  THEN 'Previous Years: 1-2'
               WHEN 365 > mtime_days AND  mtime_days >= 180  THEN 'Previous Months: 6-12'
               WHEN 180 > mtime_days AND  mtime_days >= 90   THEN 'Previous Months: 3-6'
               WHEN 90 > mtime_days AND   mtime_days >= 30   THEN 'Previous Months: 1-3'
               WHEN 30 > mtime_days AND   mtime_days >= 0    THEN 'Previous Months: 0-1'
               ELSE 'future'
           END AS mtime_age
    FROM files_with_tag
    GROUP BY tag_id, volume_id, name, atime_age, mtime_age
)
SELECT v.name AS volume_name,
       n.name AS tag,
       tpv.name AS user,
       tpv.atime_age,
       tpv.mtime_age,
       tpv.size,
       CASE
            WHEN COALESCE(v.total_capacity, 0) > 0 THEN ROUND(tpv.size * 100 / v.total_capacity, 1)
            ELSE NULL
       END AS "%_of_whole_volume",
       tpv.count,
       tpv.size / (1000 * 1000 * 1000) * CAST(COALESCE(vupc.value, '0') AS FLOAT) AS cost
FROM tag_per_vol_agg AS tpv
    INNER JOIN sf.name n ON tpv.tag_id = n.id
    LEFT JOIN sf_volumes.volume AS v ON tpv.volume_id = v.id
    LEFT JOIN sf_volumes.user_param AS vupc ON vupc.volume_id = tpv.volume_id AND vupc.name = 'cost_per_gb'
ORDER BY volume_name, tag, atime_age, mtime_age;
