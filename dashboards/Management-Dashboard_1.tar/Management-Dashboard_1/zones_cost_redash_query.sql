/***********************************************************************************************************
 *
 * Starfish Storage Corporation ("Starfish") CONFIDENTIAL
 * Unpublished Copyright (c) 2011-2021 Starfish Storage Corporation, All Rights Reserved.
 *
 * NOTICE: This file and its contents (1) constitute Starfish's "External Code" under Starfish's most-recent
 * Limited Software End-User License Agreement, and (2) is and remains the property of Starfish. The
 * intellectual and technical concepts contained herein are proprietary to Starfish and may be covered by
 * U.S. and/or foreign patents or patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly forbidden unless prior
 * written permission is obtained from Starfish. Access to the source code contained herein is hereby
 * forbidden to anyone except (A) current Starfish employees, managers, or contractors who have executed
 * confidentiality or nondisclosure agreements explicitly covering such access, and (B) licensees of
 * Starfish's software.
 *
 * ANY REPRODUCTION, COPYING, MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, OR PUBLIC DISPLAY OF OR
 * THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF STARFISH IS STRICTLY PROHIBITED
 * AND IS IN VIOLATION OF APPLICABLE LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS
 * FILE OR ITS CONTENTS AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE, OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY DESCRIBE, IN
 * WHOLE OR IN PART.
 *
 * FOR U.S. GOVERNMENT CUSTOMERS REGARDING THIS DOCUMENTATION/SOFTWARE
 *   These notices shall be marked on any reproduction of this data, in whole or in part.
 *   NOTICE: Notwithstanding any other lease or license that may pertain to, or accompany the delivery of,
 *   this computer software, the rights of the Government regarding its use, reproduction and disclosure are
 *   as set forth in Section 52.227-19 of the FARS Computer Software-Restricted Rights clause.
 *   RESTRICTED RIGHTS NOTICE: Use, duplication, or disclosure by the Government is subject to the
 *   restrictions as set forth in subparagraph (c)(1)(ii) of the Rights in Technical Data and Computer
 *   Software clause at DFARS 52.227-7013.
 *
 ***********************************************************************************************************/
-- similar to:
 -- tags_redash_query.sql
 -- tags_in_zone_redash_query.sql
-- whenever someone changes this file changing the ones above should also be considered

SELECT
--    COALESCE(volume.display_name, zone_namespace_tags_current.volume_name) AS volume_name,
    '<a href="queries/4767?p_zone='||zone.name||'">' ||zone.name|| '</a>' AS "zone",
--    namespace AS "tagset",
--    tag,
   -- mtime_age,
    SUM(ROUND(size / (1024 * 1024 * 1024.0), 2)) AS "logical size (GiB)",
    SUM(ROUND(physical_size / (1024 * 1024 * 1024.0), 2)) AS "physical size (GiB)",
    SUM(count) as "Count",
    ROUND(SUM(cost)::DECIMAL,0) as "Cost"
FROM sf_reports.tags_current as tags_current
    JOIN sf_auth.zone ON SUBSTRING(tags_current.tag, length('__zone:')+1) = zone.id::VARCHAR
    GROUP BY Zone.name
    order by zone.name
