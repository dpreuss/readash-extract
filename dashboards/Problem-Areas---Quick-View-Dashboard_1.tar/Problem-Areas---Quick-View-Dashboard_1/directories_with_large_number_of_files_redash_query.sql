SELECT count(*) 
FROM sf.dir_current dir
WHERE  (dir.local_aggrs->'total'->>'files')::BIGINT > {{number_of_files}}
or  errors ? 'ignored_huge_dir'