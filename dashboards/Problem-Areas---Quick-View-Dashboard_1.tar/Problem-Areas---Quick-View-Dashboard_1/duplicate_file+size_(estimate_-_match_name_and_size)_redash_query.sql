with dup_name_size as (
SELECT
-- f.name,
       count(*) AS count,
       SUM(f.size) / (1024*1024*1024.0) AS size_sum_gb,
 --      f.size  /  as file_size_gb
        SUM(f.size * u.value::NUMERIC) / (1024*1024*1024.0) as Cost
   FROM sf.file_current f
   INNER JOIN sf_volumes.volume v ON v.id = f.volume_id
   INNER JOIN sf_volumes.user_param u ON u.volume_id = v.id
   WHERE f.size > (50 * 1024 * 1024) AND u.name = 'cost_per_gb'
GROUP BY f.name, f.size HAVING (f.count) > 1
-- order by count desc
)
select '$'||ROUND(sum(Cost),0) as Cost, 
ROUND(sum(count), 0) as "Number of Duplicates", ROUND(avg(count),1) as "Average Duplicates per Copy", ROUND(sum(size_sum_gb),1) as "Duplicates Logical Size (GiB)"  from dup_name_size