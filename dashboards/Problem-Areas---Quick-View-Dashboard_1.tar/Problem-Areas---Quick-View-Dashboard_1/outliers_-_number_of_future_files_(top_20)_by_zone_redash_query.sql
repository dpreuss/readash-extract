select volume.name as "Volume", zone.name as "Zone", sum(count)::INTEGER as "Number of Files", sum(size) as "Size of Data"  from sf_reports.tags_current 
    JOIN sf_auth.zone ON SUBSTRING(tags_current.tag, length('__zone:')+1) = zone.id::VARCHAR
    LEFT JOIN sf_volumes.volume ON tags_current.volume_name = sf_volumes.volume.name
    WHERE SUBSTRING(tags_current.tag, 1, length('__zone:')) = '__zone:'
    AND  mtime_age = 'future'
group by volume.name, zone.id, volume_name order by sum(count) desc
limit 20