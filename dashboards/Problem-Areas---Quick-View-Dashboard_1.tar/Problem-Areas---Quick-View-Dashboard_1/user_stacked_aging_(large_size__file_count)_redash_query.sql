WITH topnsize AS
  (SELECT user_name,
          sum(SIZE) AS SIZE
   FROM sf_reports.last_time_generic_current
   GROUP BY user_name
   ORDER BY SIZE DESC
   LIMIT '{{topn}}'),
     topncount AS
  (SELECT user_name,
          sum(COUNT) AS COUNT
   FROM sf_reports.last_time_generic_current
   GROUP BY user_name
   ORDER BY COUNT DESC
   LIMIT '{{topn}}'),
     topnmerge AS
  (SELECT user_name
   FROM topnsize
   UNION SELECT user_name
   FROM topncount)
SELECT rep.user_name,
       rep.atime_age, --   rep.mtime_age,
 ROUND(sum(COUNT)::BIGINT/(1024), 0) AS Kcount,
 ROUND(sum(SIZE)::BIGINT/(1024*1024 * 1024),0) AS GiB
FROM sf_reports.last_time_generic_current rep
INNER JOIN topnmerge ON rep.user_name = topnmerge.user_name
GROUP BY rep.user_name, --   rep.mtime_age,
 rep.atime_age -- LIMIT '{{topn}}'+1