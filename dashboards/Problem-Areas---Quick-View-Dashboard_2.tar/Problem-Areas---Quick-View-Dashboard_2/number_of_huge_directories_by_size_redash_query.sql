SELECT count(*)
FROM sf.dir_current dir
WHERE  
ROUND((dir.local_aggrs->'total'->>'size')::BIGINT, 0)/(1024.0*1024.0*1024.0) > {{size_gb}} OR 
errors ? 'ignored_huge_dir'