WITH atime_user AS
  (SELECT user_name,
          atime_age,
          sum(SIZE) AS SIZE
   FROM sf_reports.last_time_generic_current
   GROUP BY user_name,
            atime_age),
     atime_total AS
  (SELECT user_name,
          sum(SIZE) as size
   FROM atime_user
   GROUP BY user_name )
SELECT a.user_name as "User", a.size/b.size * 100 as "Percent", a.size / (1024*1024*1024.0) as "Parameter Pecentage > than 3 years Old", 
       b.size / (1024*1024*1024.0) as "Total (GB)"
FROM atime_user a
JOIN atime_total b ON a.user_name = b.user_name
WHERE a.atime_age = 'Previous Years: > 3'
  AND a.size > b.size * ( {{ percentage }} / 100 ) 
  order by a.size/b.size * 100 DESC, a.size DESC
  LIMIT 20