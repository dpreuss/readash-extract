with max_depth as (
select volume_id, max(depth) as maxdepth from sf.dir_current d 
group by volume_id
)
select 

v.name as "Volume", maxdepth as "Max Depth",  (maxdepth * 0.8)::INTEGER as "80% Max Depth", count(*) as "Number of Deep Directories" from sf.dir_current d
left join max_depth m on m.volume_id = d.volume_id
left join sf_volumes.volume v ON  v.id = d.volume_Id
where depth > maxdepth * 0.8
AND depth > 15
group by v.name, maxdepth
order by maxdepth desc
limit 20