select volume_name as "Volume Name", sum(count)::INTEGER as "Number of Files", sum(size) as "Size of Data"  from sf_reports.last_time_generic_current where mtime_age = 'future'
group by volume_name order by sum(count) desc
limit 20