WITH query AS (
    SELECT
   user_name as user_name,
        atime_age as atime,
  /*       sum(ROUND(size / (1024 * 1024 * 1024.0), 2)) AS "size logical",*/
        sum(ROUND(physical_size / (1024 * 1024 * 1024.0), 1)) AS "Physical",
        ROUND(sum(cost)::NUMERIC, 0) as "Cost"
    FROM sf_reports.last_time_generic_current
    WHERE (ROUND(size / (1024 * 1024 * 1024.0), 2) > 0)
    GROUP by atime_age, user_name
    ORDER by  sum(physical_size) desc, atime_age
    LIMIT 60
) , is_empty AS (
    SELECT
        CASE
            WHEN EXISTS (SELECT * FROM query LIMIT 1) THEN 0
            ELSE 1
        END AS val
) SELECT * FROM query
UNION ALL
SELECT
    NULL AS user,
    NULL AS atime,
/*    NULL AS "size logical (GiB)", */
    NULL AS "size physical (GiB)",
    NULL AS cost
FROM is_empty WHERE is_empty.val = 1;
