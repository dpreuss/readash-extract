WITH topnsize AS
  (SELECT user_name, sum(size) as size
   FROM sf_reports.last_time_generic_history
   GROUP BY user_name
   ORDER BY size DESC LIMIT '{{topn}}'*2),
topncount AS
  (SELECT user_name, sum(count) as count
   FROM sf_reports.last_time_generic_history
   GROUP BY user_name
   ORDER BY COUNT DESC LIMIT '{{topn}}'*2),
topnmerge AS
  (SELECT user_name
   FROM topnsize
   UNION SELECT user_name
   FROM topncount)
SELECT rep.user_name,
       rep.atime_age,
       rep.mtime_age,
       ROUND(sum(count)::BIGINT/1000,0) AS Kcount,
       ROUND(sum(size)::BIGINT/(1024*1024 * 1024),0) AS TiB
FROM sf_reports.last_time_generic_history rep
   INNER JOIN topnmerge ON rep.user_name = topnmerge.user_name
GROUP BY rep.user_name,
         rep.mtime_age,
         rep.atime_age
         LIMIT '{{topn}}'+1
         